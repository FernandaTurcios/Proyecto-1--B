﻿namespace Proyecto_1_Pensamiento_Computacional;

public class Cliente //Se creó una clase  cliente para guardar los datos del cliente
{
    public string nombreCliente (string nombre)
    {
        return nombre; //Se retorna el nombre que el cliente ingresó
    }

    public int nitCliente (int nit)
    {
        return nit; //Se retorna el nit del cliente
    }
}
